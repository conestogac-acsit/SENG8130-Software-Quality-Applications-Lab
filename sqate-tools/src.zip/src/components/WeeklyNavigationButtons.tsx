import React from 'react';

interface Props {
  currentDate: Date;
  setCurrentDate: (date: Date) => void;
}

const WeeklyNavigationButtons: React.FC<Props> = ({ currentDate, setCurrentDate }) => {
  const goToToday = () => setCurrentDate(new Date());

  const goToPrevious = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() - 7);
    setCurrentDate(newDate);
  };

  const goToNext = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + 7);
    setCurrentDate(newDate);
  };

  return (
    <div className="flex justify-center gap-4 mt-4">
      <button
        onClick={goToPrevious}
        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded"
      >
        Back
      </button>
      <button
        onClick={goToToday}
        className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded"
      >
        Today
      </button>
      <button
        onClick={goToNext}
        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded"
      >
        Next
      </button>
    </div>
  );
};

export default WeeklyNavigationButtons;
