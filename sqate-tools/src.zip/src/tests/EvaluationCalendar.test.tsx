import React from 'react';
import { render, screen } from '@testing-library/react';
import EvaluationCalendar from '../components/EvaluationCalendar';
import { View } from 'react-big-calendar';

// Mock events
const mockEvents = [
  {
    title: 'Test Event',
    start: new Date('2025-06-01T10:00:00'),
    end: new Date('2025-06-01T11:00:00'),
  },
];

// Basic test
describe('EvaluationCalendar', () => {
  it('renders without crashing', () => {
    render(
      <EvaluationCalendar
        events={mockEvents}
        date={new Date('2025-06-01')}
        onNavigate={() => {}}
        view="month" // Make sure it's not undefined
        onView={() => {}}
      />
    );
    // Check that the component rendered an element from the calendar
    const calendar = screen.getByRole('grid');
    expect(calendar).toBeInTheDocument();
  });

  it('displays the event title', () => {
    render(
      <EvaluationCalendar
        events={mockEvents}
        date={new Date('2025-06-01')}
        onNavigate={() => {}}
        view="month"
        onView={() => {}}
      />
    );
    expect(screen.getByText('Test Event')).toBeInTheDocument();
  });
});
