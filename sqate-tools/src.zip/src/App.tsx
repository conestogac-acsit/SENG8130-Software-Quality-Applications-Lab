import React, { useState } from 'react';
import UploadCsv from './components/UploadCsv';
import EvaluationCalendar from './components/EvaluationCalendar';
import WeeklyNavigationButtons from './components/WeeklyNavigationButtons';

type Evaluation = {
  Course: string;
  Title: string;
  Type: string;
  Weight: string;
  Date: string;
  Time: string;
};

type CalendarEvent = {
  title: string;
  start: Date;
  end: Date;
  allDay?: boolean;
};

const App: React.FC = () => {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());

  const handleCsvUpload = (data: Evaluation[]) => {
    const calendarEvents = data
      .map((evalItem): CalendarEvent | null => {
        const start = new Date(evalItem.Date);
        if (isNaN(start.getTime())) {
          console.warn('Invalid date:', evalItem.Date);
          return null;
        }
        const end = new Date(start);
        end.setDate(start.getDate() + 1);
        return {
          title: ${evalItem.Course} - ${evalItem.Title},
          start,
          end,
          allDay: true,
        };
      })
      .filter((ev): ev is CalendarEvent => ev !== null);

    setEvents(calendarEvents);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Centralized Evaluation Calendar</h1>
      <UploadCsv onUpload={handleCsvUpload} />
      <WeeklyNavigationButtons
        currentDate={currentDate}
        setCurrentDate={setCurrentDate}
      />
      <EvaluationCalendar events={events} currentDate={currentDate} />
    </div>
  );
};

export default App;
